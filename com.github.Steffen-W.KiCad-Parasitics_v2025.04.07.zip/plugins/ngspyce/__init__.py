"""ngspyce, a python interface to the ngspice circuit simulator"""
from .ngspyce import *
